﻿namespace MotorInsurance
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SubmitBtn = new System.Windows.Forms.Button();
            this.NoClaimBtn = new System.Windows.Forms.Button();
            this.YesClaimBtn = new System.Windows.Forms.Button();
            this.TxtName = new System.Windows.Forms.TextBox();
            this.TxtOccupation = new System.Windows.Forms.TextBox();
            this.TxtDay = new System.Windows.Forms.TextBox();
            this.TxtMonth = new System.Windows.Forms.TextBox();
            this.TxtYear = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblStart = new System.Windows.Forms.Label();
            this.TxtStartDay = new System.Windows.Forms.TextBox();
            this.TxtStartMonth = new System.Windows.Forms.TextBox();
            this.TxtStartYear = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblClaim = new System.Windows.Forms.Label();
            this.TxtClaimDay = new System.Windows.Forms.TextBox();
            this.TxtClaimMonth = new System.Windows.Forms.TextBox();
            this.TxtClaimYear = new System.Windows.Forms.TextBox();
            this.lstOutput = new System.Windows.Forms.ListBox();
            this.lstDecline = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblNumClaims = new System.Windows.Forms.Label();
            this.TxtNumClaims = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblStart2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SubmitBtn
            // 
            this.SubmitBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.SubmitBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitBtn.ForeColor = System.Drawing.SystemColors.Menu;
            this.SubmitBtn.Location = new System.Drawing.Point(115, 399);
            this.SubmitBtn.Name = "SubmitBtn";
            this.SubmitBtn.Size = new System.Drawing.Size(95, 23);
            this.SubmitBtn.TabIndex = 0;
            this.SubmitBtn.Text = "Submit Driver";
            this.SubmitBtn.UseVisualStyleBackColor = false;
            this.SubmitBtn.Click += new System.EventHandler(this.SubmitBtn_Click);
            // 
            // NoClaimBtn
            // 
            this.NoClaimBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.NoClaimBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NoClaimBtn.ForeColor = System.Drawing.SystemColors.Window;
            this.NoClaimBtn.Location = new System.Drawing.Point(164, 282);
            this.NoClaimBtn.Name = "NoClaimBtn";
            this.NoClaimBtn.Size = new System.Drawing.Size(75, 23);
            this.NoClaimBtn.TabIndex = 1;
            this.NoClaimBtn.Text = "No";
            this.NoClaimBtn.UseVisualStyleBackColor = false;
            this.NoClaimBtn.Click += new System.EventHandler(this.NoClaimBtn_Click);
            // 
            // YesClaimBtn
            // 
            this.YesClaimBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.YesClaimBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.YesClaimBtn.ForeColor = System.Drawing.SystemColors.Window;
            this.YesClaimBtn.Location = new System.Drawing.Point(83, 282);
            this.YesClaimBtn.Name = "YesClaimBtn";
            this.YesClaimBtn.Size = new System.Drawing.Size(75, 23);
            this.YesClaimBtn.TabIndex = 2;
            this.YesClaimBtn.Text = "Yes";
            this.YesClaimBtn.UseVisualStyleBackColor = false;
            this.YesClaimBtn.Click += new System.EventHandler(this.YesClaimBtn_Click);
            // 
            // TxtName
            // 
            this.TxtName.Location = new System.Drawing.Point(121, 22);
            this.TxtName.Name = "TxtName";
            this.TxtName.Size = new System.Drawing.Size(149, 20);
            this.TxtName.TabIndex = 3;
            // 
            // TxtOccupation
            // 
            this.TxtOccupation.Location = new System.Drawing.Point(121, 48);
            this.TxtOccupation.Name = "TxtOccupation";
            this.TxtOccupation.Size = new System.Drawing.Size(149, 20);
            this.TxtOccupation.TabIndex = 4;
            // 
            // TxtDay
            // 
            this.TxtDay.Location = new System.Drawing.Point(158, 73);
            this.TxtDay.Name = "TxtDay";
            this.TxtDay.Size = new System.Drawing.Size(31, 20);
            this.TxtDay.TabIndex = 5;
            // 
            // TxtMonth
            // 
            this.TxtMonth.Location = new System.Drawing.Point(195, 73);
            this.TxtMonth.Name = "TxtMonth";
            this.TxtMonth.Size = new System.Drawing.Size(30, 20);
            this.TxtMonth.TabIndex = 6;
            // 
            // TxtYear
            // 
            this.TxtYear.Location = new System.Drawing.Point(231, 74);
            this.TxtYear.Name = "TxtYear";
            this.TxtYear.Size = new System.Drawing.Size(39, 20);
            this.TxtYear.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label1.Location = new System.Drawing.Point(33, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label2.Location = new System.Drawing.Point(21, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "Occupation:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label3.Location = new System.Drawing.Point(8, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(149, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "Date of birth(dd/mm/yyyy):";
            // 
            // lblStart
            // 
            this.lblStart.AutoSize = true;
            this.lblStart.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStart.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblStart.Location = new System.Drawing.Point(17, 101);
            this.lblStart.Name = "lblStart";
            this.lblStart.Size = new System.Drawing.Size(64, 12);
            this.lblStart.TabIndex = 11;
            this.lblStart.Text = "Start Date:";
            // 
            // TxtStartDay
            // 
            this.TxtStartDay.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtStartDay.Location = new System.Drawing.Point(92, 98);
            this.TxtStartDay.Name = "TxtStartDay";
            this.TxtStartDay.Size = new System.Drawing.Size(31, 20);
            this.TxtStartDay.TabIndex = 12;
            // 
            // TxtStartMonth
            // 
            this.TxtStartMonth.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtStartMonth.Location = new System.Drawing.Point(129, 98);
            this.TxtStartMonth.Name = "TxtStartMonth";
            this.TxtStartMonth.Size = new System.Drawing.Size(30, 20);
            this.TxtStartMonth.TabIndex = 13;
            // 
            // TxtStartYear
            // 
            this.TxtStartYear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtStartYear.Location = new System.Drawing.Point(164, 98);
            this.TxtStartYear.Name = "TxtStartYear";
            this.TxtStartYear.Size = new System.Drawing.Size(38, 20);
            this.TxtStartYear.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(73, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(182, 12);
            this.label5.TabIndex = 15;
            this.label5.Text = "Have you any claims? (Optional)";
            // 
            // lblClaim
            // 
            this.lblClaim.AutoSize = true;
            this.lblClaim.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClaim.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblClaim.Location = new System.Drawing.Point(18, 360);
            this.lblClaim.Name = "lblClaim";
            this.lblClaim.Size = new System.Drawing.Size(158, 12);
            this.lblClaim.TabIndex = 16;
            this.lblClaim.Text = "Date of claim(Most recent) :";
            this.lblClaim.Visible = false;
            // 
            // TxtClaimDay
            // 
            this.TxtClaimDay.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtClaimDay.ForeColor = System.Drawing.SystemColors.InfoText;
            this.TxtClaimDay.Location = new System.Drawing.Point(179, 357);
            this.TxtClaimDay.Name = "TxtClaimDay";
            this.TxtClaimDay.Size = new System.Drawing.Size(31, 20);
            this.TxtClaimDay.TabIndex = 17;
            this.TxtClaimDay.Visible = false;
            // 
            // TxtClaimMonth
            // 
            this.TxtClaimMonth.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtClaimMonth.Location = new System.Drawing.Point(216, 357);
            this.TxtClaimMonth.Name = "TxtClaimMonth";
            this.TxtClaimMonth.Size = new System.Drawing.Size(30, 20);
            this.TxtClaimMonth.TabIndex = 18;
            this.TxtClaimMonth.Visible = false;
            // 
            // TxtClaimYear
            // 
            this.TxtClaimYear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtClaimYear.Location = new System.Drawing.Point(252, 357);
            this.TxtClaimYear.Name = "TxtClaimYear";
            this.TxtClaimYear.Size = new System.Drawing.Size(38, 20);
            this.TxtClaimYear.TabIndex = 19;
            this.TxtClaimYear.Visible = false;
            // 
            // lstOutput
            // 
            this.lstOutput.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstOutput.FormattingEnabled = true;
            this.lstOutput.ItemHeight = 12;
            this.lstOutput.Location = new System.Drawing.Point(341, 113);
            this.lstOutput.Name = "lstOutput";
            this.lstOutput.Size = new System.Drawing.Size(587, 172);
            this.lstOutput.TabIndex = 22;
            // 
            // lstDecline
            // 
            this.lstDecline.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstDecline.FormattingEnabled = true;
            this.lstDecline.ItemHeight = 12;
            this.lstDecline.Location = new System.Drawing.Point(342, 318);
            this.lstDecline.Name = "lstDecline";
            this.lstDecline.Size = new System.Drawing.Size(586, 112);
            this.lstDecline.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label4.Location = new System.Drawing.Point(339, 302);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 12);
            this.label4.TabIndex = 24;
            this.label4.Text = "Decline";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label6.Location = new System.Drawing.Point(339, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 12);
            this.label6.TabIndex = 25;
            this.label6.Text = "Driver Details";
            // 
            // lblNumClaims
            // 
            this.lblNumClaims.AutoSize = true;
            this.lblNumClaims.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumClaims.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblNumClaims.Location = new System.Drawing.Point(18, 329);
            this.lblNumClaims.Name = "lblNumClaims";
            this.lblNumClaims.Size = new System.Drawing.Size(198, 12);
            this.lblNumClaims.TabIndex = 26;
            this.lblNumClaims.Text = "Please enter the number of claims:";
            this.lblNumClaims.Visible = false;
            // 
            // TxtNumClaims
            // 
            this.TxtNumClaims.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNumClaims.Location = new System.Drawing.Point(218, 326);
            this.TxtNumClaims.Name = "TxtNumClaims";
            this.TxtNumClaims.Size = new System.Drawing.Size(28, 20);
            this.TxtNumClaims.TabIndex = 27;
            this.TxtNumClaims.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.TxtName);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.TxtOccupation);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.TxtDay);
            this.groupBox1.Controls.Add(this.TxtMonth);
            this.groupBox1.Controls.Add(this.TxtYear);
            this.groupBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.groupBox1.Location = new System.Drawing.Point(13, 131);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(286, 100);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Driver Details";
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = global::MotorInsurance.Properties.Resources.applied;
            this.pictureBox1.Image = global::MotorInsurance.Properties.Resources.applied;
            this.pictureBox1.InitialImage = global::MotorInsurance.Properties.Resources.applied;
            this.pictureBox1.Location = new System.Drawing.Point(609, -45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(354, 133);
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // lblStart2
            // 
            this.lblStart2.AutoSize = true;
            this.lblStart2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStart2.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lblStart2.Location = new System.Drawing.Point(11, 76);
            this.lblStart2.Name = "lblStart2";
            this.lblStart2.Size = new System.Drawing.Size(304, 12);
            this.lblStart2.TabIndex = 30;
            this.lblStart2.Text = "Please enter the start date you wish to start the policy";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(940, 451);
            this.Controls.Add(this.lblStart2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TxtNumClaims);
            this.Controls.Add(this.lblNumClaims);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lstDecline);
            this.Controls.Add(this.lstOutput);
            this.Controls.Add(this.TxtClaimYear);
            this.Controls.Add(this.TxtClaimMonth);
            this.Controls.Add(this.TxtClaimDay);
            this.Controls.Add(this.lblClaim);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TxtStartYear);
            this.Controls.Add(this.TxtStartMonth);
            this.Controls.Add(this.TxtStartDay);
            this.Controls.Add(this.lblStart);
            this.Controls.Add(this.YesClaimBtn);
            this.Controls.Add(this.NoClaimBtn);
            this.Controls.Add(this.SubmitBtn);
            this.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.Name = "Form1";
            this.Text = "Applied Systems - Motor Insurance Calculator";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SubmitBtn;
        private System.Windows.Forms.Button NoClaimBtn;
        private System.Windows.Forms.Button YesClaimBtn;
        private System.Windows.Forms.TextBox TxtName;
        private System.Windows.Forms.TextBox TxtOccupation;
        private System.Windows.Forms.TextBox TxtDay;
        private System.Windows.Forms.TextBox TxtMonth;
        private System.Windows.Forms.TextBox TxtYear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblStart;
        private System.Windows.Forms.TextBox TxtStartDay;
        private System.Windows.Forms.TextBox TxtStartMonth;
        private System.Windows.Forms.TextBox TxtStartYear;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblClaim;
        private System.Windows.Forms.TextBox TxtClaimDay;
        private System.Windows.Forms.TextBox TxtClaimMonth;
        private System.Windows.Forms.TextBox TxtClaimYear;
        private System.Windows.Forms.ListBox lstOutput;
        private System.Windows.Forms.ListBox lstDecline;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblNumClaims;
        private System.Windows.Forms.TextBox TxtNumClaims;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblStart2;
    }
}

