﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MotorInsurance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        Driver driver;
        int driverCount = 0; // determine the amount of drivers added 
        int totalPolicyClaims = 0; // total amount of claims within the policy 
        double Premium = 500; // Starting value

        private void SubmitBtn_Click(object sender, EventArgs e)
        {

            if (driverCount == 5) // Max Amount of Drivers  per policy 
            {

                MessageBox.Show("You have reached the maximum amount of driver per policy");

                //This will clear all textboxes and prevents the user from entering using the buttons
                TxtName.ReadOnly = true;
                TxtName.Clear();

                TxtOccupation.ReadOnly = true;
                TxtOccupation.Clear();

                TxtDay.ReadOnly = true;
                TxtDay.Clear();

                TxtMonth.ReadOnly = true;
                TxtMonth.Clear();

                TxtYear.ReadOnly = true;
                TxtYear.Clear();

                TxtClaimDay.ReadOnly = true;
                TxtClaimDay.Clear();

                TxtClaimMonth.ReadOnly = true;
                TxtClaimMonth.Clear();

                TxtClaimYear.ReadOnly = true;
                TxtClaimYear.Clear();

                TxtNumClaims.ReadOnly = true;
                TxtNumClaims.Clear();

                SubmitBtn.IsAccessible = false;
   
            }

            if (driverCount < 5) // If there has only been less than 5 driver created
            {
                ValidateDriver(); // Method used for exception handling to validate the users data
            }
        }

        private void YesClaimBtn_Click(object sender, EventArgs e)
        {
            // Once the user clicks on yes all textboxes and labels that involves claims appear 
            lblClaim.Visible = true;
            TxtClaimDay.Visible = true;
            TxtClaimMonth.Visible = true;
            TxtClaimYear.Visible = true;
            lblNumClaims.Visible = true;
            TxtNumClaims.Visible = true;

        }

        public void CreateDriver()
        {
           //Start Date of Policy  
           int startDay = int.Parse(TxtStartDay.Text);

           int startMonth = int.Parse(TxtStartMonth.Text);

           int startYear = int.Parse(TxtStartYear.Text);

           DateTime startDate = new DateTime(startYear, startMonth, startDay);

            if (startDate < DateTime.Today)
            {
                lstDecline.Items.Add("Start Date of Policy"); // Decline Rule 
            }
      
            string driverName = TxtName.Text;
            string Occupation = TxtOccupation.Text;
           
            //Determine Premium based on Occupation 
            if (Occupation == "Chauffeur" || Occupation == "chauffeur")
            {
                Premium = Premium + 50; 
                
            }

            else if (Occupation == "Accountant" || Occupation == "accountant")
            {
                Premium = Premium - 50; 
              
            }
            else
            {
                
            }

            //Set Drivers date of birth 
            int day = int.Parse(TxtDay.Text);

            int month = int.Parse(TxtMonth.Text);

            int year = int.Parse(TxtYear.Text);

            DateTime DateOfBirth = new DateTime(year, month, day);
       

            //Calculate Drivers Age based on the date of birth given
            DateTime date = DateTime.Today;
            int Age = date.Year - DateOfBirth.Year;

            if (date.Month < DateOfBirth.Month || (date.Month == DateOfBirth.Month && date.Day < DateOfBirth.Day))
                Age--;

            // Premium Age Rules and Decline Rules
            if (Age >= 21 && Age <= 25)
            {
                Premium = Premium + 100; 
            }

            else if (Age >= 26 && Age <= 75)
            {
                Premium = Premium - 50; 
            }


            else if (Age < 21) // Decline Rule
            {
                lstDecline.Items.Add("Age of Youngest Driver" + " - " + driverName + " ,  Age: " + Age); 

            }
            else // >75 Decline Rule
            {
                lstDecline.Items.Add("Age of Oldest Driver" + " - " + driverName + " ,  Age: " + Age);

            }

            // Set Claim date

            int claimDay = int.Parse(TxtClaimDay.Text);

            int claimMonth = int.Parse(TxtClaimMonth.Text);

            int claimYear = int.Parse(TxtClaimYear.Text);

            DateTime claimDate = new DateTime(claimYear, claimMonth, claimDay); // Date of the claim 
            
            
          // Decline Rule
           int diff = startDate.Year - claimDate.Year;

            if (diff == 1)
            {
                Premium = Premium + 100; 
            }

            else if (diff >= 2 && diff <= 5) 
            {
                Premium = Premium + 50; 
            }
            
            else // this will return for all dates greater than 5 and if the user clicks the no claim button which gives the default value  
            {
               
            }
            
            int NumClaims = int.Parse(TxtNumClaims.Text); // Number of claims the driver has 

            totalPolicyClaims = totalPolicyClaims + NumClaims; //Total Policy claims
            

            //Decline Rules - Claims
            if (NumClaims > 3) 
            {
                lstDecline.Items.Add("Driver has more than 2 claims"); // Decline Message 
            }

            if (totalPolicyClaims > 3)
            {
                lstDecline.Items.Add("Policy has more than 3 claims"); // Decline Message
            }


            driver = new Driver(driverName, Occupation, Age, DateOfBirth, NumClaims, Premium);
           

            try// Displays Contents within list box and exception handling
            {
             
                lstOutput.Items.Add("Name : " + driver.driverName);
                lstOutput.Items.Add("Occupation : " + driver.Occupation);
                lstOutput.Items.Add("Age : " + driver.Age);//Might not need this
                lstOutput.Items.Add("Date of Birth  : " + driver.DateOfBirth); // Displays time how do we remove that?
                lstOutput.Items.Add("Number of Claims : " + driver.NumClaims);
                lstOutput.Items.Add("Premium : " + driver.Premium);
                lstOutput.Items.Add("\n");

            }
            catch (NullReferenceException) // Empty details
            {
                MessageBox.Show("Please enter all details");
            }
            catch (Exception ex) // ?? - All other Exceptions
            {
                MessageBox.Show(ex.Message);
            }

        }
        
        public void AddAnotherDriver() // All the user to add another driver to the policy
        {

            // Prompt whether or not the user would like to add another driver to the policy 
            DialogResult dr = MessageBox.Show("Would you like to add another driver to the policy? (Maximum of 5 Drivers)",
                     "Add another Driver", MessageBoxButtons.YesNo);
            switch (dr)
            {
                case DialogResult.Yes:
                    
                    

                    //Start Date textbox are removed 
                    this.Controls.Remove(TxtStartDay);
                    this.Controls.Remove(TxtStartMonth);
                    this.Controls.Remove(TxtStartYear);
                    this.Controls.Remove(lblStart);
                    this.Controls.Remove(lblStart2);

                    //Clear textboxes
                    TxtName.Clear();
                    TxtOccupation.Clear();
                    TxtDay.Clear();
                    TxtMonth.Clear();
                    TxtYear.Clear();
                    TxtClaimDay.Clear();
                    TxtClaimMonth.Clear();
                    TxtClaimYear.Clear();
                    TxtNumClaims.Clear();
                    break;

                case DialogResult.No:

                    break;
            }
            
        }

        private void NoClaimBtn_Click(object sender, EventArgs e)
        {
            //Once the user clicks the no claims buttons these text boxes still need a value so I used exceptions
            // and set the values to the defualt date value  // 01/01/0001

            if (string.IsNullOrWhiteSpace(TxtClaimDay.Text)) // Prevents null Claim Date  - Day
            {
                TxtClaimDay.Text = "01"; //Default  Value
                
            }
            if (string.IsNullOrWhiteSpace(TxtClaimMonth.Text)) // Prevents null Claim Date - Month
            {
                TxtClaimMonth.Text = "01"; // Default Value
                
            }
            if (string.IsNullOrWhiteSpace(TxtClaimYear.Text)) // Prevents null Claim Date - Year
            {
                TxtClaimYear.Text = "0001"; //Defualt Value
              
            }
            if (string.IsNullOrWhiteSpace(TxtNumClaims.Text)) // Prevents null value - Number of Claims
            {
                TxtNumClaims.Text = "0";
               
            }

            if (driverCount == 5) // Max Amount of Drivers 
            {

                MessageBox.Show("You have reached the maximum amount of driver per policy");
                
                //This will clear all textboxes and prevent the user from entering using the buttons
                TxtName.ReadOnly = true;
                TxtName.Clear();

                TxtOccupation.ReadOnly = true;
                TxtOccupation.Clear();

                TxtDay.ReadOnly = true;
                TxtDay.Clear();

                TxtMonth.ReadOnly = true;
                TxtMonth.Clear();

                TxtYear.ReadOnly = true;
                TxtYear.Clear();

                TxtClaimDay.ReadOnly = true;
                TxtClaimDay.Clear();

                TxtClaimMonth.ReadOnly = true;
                TxtClaimMonth.Clear();

                TxtClaimYear.ReadOnly = true;
                TxtClaimYear.Clear();

                TxtNumClaims.ReadOnly = true;
                TxtNumClaims.Clear();

                SubmitBtn.IsAccessible = false;

            }

            if (driverCount < 5) 
            {
                ValidateDriver();
            }
        }

        public void ValidateDriver() // Method used to ensure data integrity by using exceptions 
        {
            try { 
            // Start Date - Exception Handling
            if (string.IsNullOrWhiteSpace(TxtStartDay.Text)) // Prevents null Day 
            {
                MessageBox.Show("Please enter the day , you wish to start this policy");
                return;
            }
            if (string.IsNullOrWhiteSpace(TxtStartMonth.Text)) // Prevents null Month
            {
                MessageBox.Show("Please enter the month , you wish to start this policy");
                return;
            }

            if (string.IsNullOrWhiteSpace(TxtStartYear.Text)) // Prevents null Year
            {
                MessageBox.Show("Please enter the year, you wish to start this policy");
                return;
            }


            //Date of Birth - Exception Handling 
            if (string.IsNullOrWhiteSpace(TxtDay.Text)) // Prevents null Date of Birth - Day  
            {
                MessageBox.Show("Please enter the day of the drivers date of birth");
                return;
            }
            if (string.IsNullOrWhiteSpace(TxtMonth.Text)) // Prevents null Date of Birth - Month
            {
                MessageBox.Show("Please enter the month of the drivers date of birth");
                return;
            }
            if (string.IsNullOrWhiteSpace(TxtYear.Text)) // Prevents null Date of Birth - Year
            {
                MessageBox.Show("Please enter the year of the drivers date of birth");
                return;
            }

      
            //Claim Date - Exception Handling
            if (string.IsNullOrWhiteSpace(TxtClaimDay.Text)) // Prevents null Claim Date  - Day
            {
                    MessageBox.Show("Please enter the day of the claim");
                    return;
            }
            if (string.IsNullOrWhiteSpace(TxtClaimMonth.Text)) // Prevents null Claim Date - Month
            {
                    MessageBox.Show("Please enter the month of the claim");
                    return;
            }
            if (string.IsNullOrWhiteSpace(TxtClaimYear.Text)) // Prevents null Claim Date - Year
            {
                    MessageBox.Show("Please enter the year of the claim");
                    return;
            }
            if (string.IsNullOrWhiteSpace(TxtNumClaims.Text)) // Prevents null value - Number of Claims
            {
                    MessageBox.Show("Please enter the number of claims the driver has");
                    return;
            }


                else // this will run if the  data is valid 
                {
                    CreateDriver(); // Calls a method which creates a driver 
                    driverCount++; // increases the amount of drivers 
                    AddAnotherDriver();
                }

            }
            catch(FormatException) // Int.Parse Exception , makes the user enter an appropriate value
            {
                MessageBox.Show("Incorrect value");
            }
           
        }
               
        
    }

}
