﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorInsurance
{

    public class Driver  
    {
        //Properties
        public string driverName { get; set; }      // Name of Driver
        public string Occupation { get; set; }      // Occupation of the Driver
        public int Age { get; set; }                // Age of driver
        public DateTime DateOfBirth { get; set; }   // Date of Birth 
        public int NumClaims { get; set; }          // Number of Claims
        public double Premium { get; set; }         // Premium Cost


        public Driver()//Default Constructor
        {

            driverName = "";
            Occupation = "";
            Age = 0;
            DateOfBirth = DateTime.MinValue;// Default value 01/01/0001
            NumClaims = 0;
            Premium = 500;
           
        }
        
        public Driver(string drivername, string occupation, int age, DateTime dateOfBirth, int claims, double premium) 
        {
            driverName = drivername;
            Occupation = occupation;
            Age = age;
            DateOfBirth = dateOfBirth;
            NumClaims = claims;
            Premium = premium;
           
        }
        
        public override string ToString() 
        {
            return String.Format("Driver Name: " + driverName + " Driver Occupation: " + Occupation + " Driver Age:" + Age + " Driver Date of Birth: " + DateOfBirth + " Premium: " + Premium);
        }
    }
}
